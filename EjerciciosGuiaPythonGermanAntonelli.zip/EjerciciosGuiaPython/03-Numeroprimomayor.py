# -*- coding: utf-8 -*-
# Programa: 05-MultiploPrimoMayor.py
# Objetivo: Obtiene el mayor divisor primo de un numero dado.
# Autor: German Antonelli
# Fecha: 03/Febrero/2020
import math

def multiplo_primo_menor(numero):
    '''
    Obtener el menor multiplo de un numero en el rango de 2 hasta n.
    El resultado siempre sera un numero primo.

    Parametros:
    numero: el valor del numero a calcular el multiplo.
    '''
    assert numero >= 2 # continuar solo si el valor es mayor o igual que 2
    for i in range(2, int(math.sqrt(numero)) + 1):
        if numero % i == 0:
            return i

    return numero # numero es primo


def calcular_primo_mayor(numero):
    '''
    Retorna el primo multiplo mayor de un numero.

    Parametros:
    numero: el numero a calcular el primo multiplo mayor.
    '''
    while True:
        menor = multiplo_primo_menor(numero)
        if menor < numero:
            numero //= menor
        else:
            return numero

if __name__ == "__main__":
    print(calcular_primo_mayor(600851475143))