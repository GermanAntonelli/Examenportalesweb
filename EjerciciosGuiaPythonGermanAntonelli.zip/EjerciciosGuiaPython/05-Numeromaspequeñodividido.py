# _*_ coding: utf-8 *_*
# Programa: 5to programa
# Objetivo: Encontrar numero menor que dividido entre 1-20 de como residuo 0
# Autor: German Antonelli
# Fecha: 2/2/2020

numeroCorrecto = 0

for i in range(1,3000):
    for a in range(1,11): 
        if (i % a == 0):
            numeroCorrecto =  numeroCorrecto + 1
            #print(i, " % ",a," = ", i%a)
        else:
            numeroCorrecto = 0
            #print("Se reinicia el numero ya que no es divisible por todos")
        if numeroCorrecto == 10:
            print(i)