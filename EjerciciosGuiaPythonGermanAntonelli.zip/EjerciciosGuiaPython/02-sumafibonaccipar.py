#_*_coding:utf-8 _*_
#Programa: 03-Multiplos3y5.py
#Objetivo: retorna los numros pares dentro de la sucesion de fibonacci
#Autor: German Antonelli
#Fecha: 29/enero/2020


def suma_fibonacci_par(numero):
    '''
    Retorna la suma de todos los numeros pares que se generan en la sucesion de Fibonacci.
    La sucesion realiza hasta el numero menor que el valor dado.

    Parametros:
    numero: el valor maximo a generar en la sucesion
    '''
    suma = 0
    x = 1 #Representa el valor actual de la sucesion
    y = 2 #rpresenta el valor siguiente en la sucesion de fibonacci
    while x <= numero:
        if x % 2 == 0:
            suma += x
        #Asignacion multiple
        x, y = y, x + y
    return suma


if __name__ == "__main__":
    print(suma_fibonacci_par(4000000))