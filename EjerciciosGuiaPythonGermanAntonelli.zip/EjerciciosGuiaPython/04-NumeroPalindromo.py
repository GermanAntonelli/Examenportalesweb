﻿#_*_coding:utf-8 _*_
#Programa: 01-Ejercicio.py
#Objetivo: listar numeros palindromos 
#Autor: German Antonelli
#Fecha: 28/enero/2020

"""
Un número palíndromo es aquel número que se lee igual de izquierda a derecha que de
derecha a izquierda. El palíndromo más grande que se puede obtener por el producto
de dos números de dos dígitos es 9009 = 91 x 99.
Encuentre el palíndromo más grande que se puede encontrar por el producto de
números de 3 dígitos.
"""

def numero_palindromo(numero):
   if str(numero)==str(numero)[::-1]: #utilizamos el doble dos puntos por que es contenedor de string
        return True
   else:
        return False
palindromomaximo=1
for numero1 in range(100,999):
    for numero2 in range(100,999):
        producto=numero1*numero2  
        if numero_palindromo(producto):
            if producto>palindromomaximo:
                maxPalindrome=producto
                maxnum1=numero1
                maxnum2=numero2

if __name__ == "__main__":
 print(palindromomaximo,maxnum1,maxnum2)