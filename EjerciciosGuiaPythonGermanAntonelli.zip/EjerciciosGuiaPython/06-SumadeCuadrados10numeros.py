#_*_coding:utf-8 _*_
#Programa: 06-SumadeCuadrados10numeros.py
#Objetivo: Hacer la suma de 10 numeros naturales y encontrar el cuadrado
#          de los primeros numeros naturales.
#Autor: German Antonelli
#Fecha: 5/febrero/2020

'''
La suma de los cuadrados de los primeros 10 números naturales es:
1
2 + 2
2 + 3
2 + ⋯ + 102 = 385
El cuadrado de la suma de los primeros números naturales es:
(1 + 2 + 3 + ⋯ + 10)
2 = 552 = 3025
Por lo tanto, la diferencia entre la suma de los cuadrados de los primeros 10 números
naturales y el cuadrado de la suma de los primeros 10 números naturales es 3025 −
385 = 2640.
Encontrar la diferencia entre la suma de los cuadrados de los primeros 100 números
naturales y la suma del cuadrado de los primeros 10 números naturales.

link: https://lasmatematicas.eu/2017/09/22/suma-de-los-cuadrados-de-los-n-primeros-numeros-naturales/
'''


def sumaDeCuadrados(listaNumeros):
    '''
    Retorna el resultado de la suma de los numeros
    Parametros: 
    listaNumeros: en este segmento lo que se nos pide es listar los resultados de los 
                  valores de la suma y al momento de elevar los numeros naturales al cuadrado.
    '''
    suma=0
    for numero in listaNumeros:
        suma+=numero**2
    return suma

def cuadradoDeSumas(listaNumeros):
    '''
    Retorna el resultado de la suma de los numeros
    Parametros: 
    listaNumeros: en este segmento lo que se nos pide es listar los resultados de los 
                  valores de la suma y al momento de elevar los numeros naturales al cuadrado.
    '''
    suma=0
    for numero in listaNumeros:
        suma+=numero
    suma=suma**2
    return suma
sumDCuad=sumaDeCuadrados(range(1,101))
cuadDSum=cuadradoDeSumas(range(1,101))
print (cuadDSum,sumDCuad,cuadDSum-sumDCuad)