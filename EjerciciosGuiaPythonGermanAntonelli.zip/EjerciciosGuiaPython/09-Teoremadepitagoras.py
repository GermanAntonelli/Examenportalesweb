#_*_coding:utf-8 _*_
#Programa: 09-Teoremadepiagoras.py
#Objetivo: Crear programa el cual sea elaborado en cuestion del teorema de pitagoras
#Autor: German Antonelli
#Fecha: 8/febrero/2020
import math
def pitagoras():
    #buscando la hipotenusa
    c1=float(input("Ingrese cateto 1: "))
    c2=float(input("Ingrese cateto 2: "))
    hipotenusa=math.sqrt(c1**2 + c2**2)
    print("La hiponetusa es igual a ",hipotenusa)
    #buscando el cateto 1
    c2=float(input("Ingrese Cateto 2:"))
    hipotenusa=float(input("Ingrese la hipotenusa: "))
    c1= math.sqrt(hipotenusa**2 + c2**2)
    print("El cateto 1 es igual a ", c1)
    #buscando el cateto 2
    c1=float(input("Ingrese Cateto 1:"))
    hipotenusa=float(input("Ingrese la hipotenusa: "))
    c1= math.sqrt(hipotenusa**2 + c1**2)
    print("El cateto 1 es igual a ", c2)
pitagoras()