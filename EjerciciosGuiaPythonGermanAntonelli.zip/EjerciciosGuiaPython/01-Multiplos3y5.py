#_*_coding:utf-8 _*_
#Programa: 03-Multiplos3y5.py
#Objetivo: listar numeros naturale en mutiplos de tres y cinco
#Autor: German Antonelli
#Fecha: 28/enero/2020



def suma_multiplos_3_o_5(numero):
    '''
    Retorna la suma de los multiplos de 3 o 5 menores 
    que el numero ingresado

    Parametros:
    numero: el valor maximo -1 ha calcular
    '''
    #al momento de tratar ejecuciones en una sola linea se le llama composicion
    suma = sum(x for x in range(numero) if (x % 3 == 0 or x % 5 == 0))
    return suma

if __name__ == "__main__:":
  print(suma_multiplos_3_o_5(1000))
