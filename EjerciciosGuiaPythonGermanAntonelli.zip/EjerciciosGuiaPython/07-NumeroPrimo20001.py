#_*_coding:utf-8 _*_
#Programa: 07-NUmeroPrimo20001.py
#Objetivo: Hacer la suma de 10 numeros naturales y encontrar el cuadrado
#          de los primeros numeros naturales.
#Autor: German Antonelli
#Fecha: 5/febrero/2020

numeroAEvaluar=1
divisorActual=2
maxPrimo=2
listaPrimos=[2] #iniciamos con el primer primo conocido
cuenta=0
while len(listaPrimos)<20001:
 numeroAEvaluar+=2 #los primos seran siempre impares
 esPrimo=True
 for i in listaPrimos:
  if numeroAEvaluar%i==0:
   esPrimo=False
  break
 if not esPrimo:
   continue 
 divisorActual=maxPrimo
 while divisorActual<=numeroAEvaluar**0.5:#ver propiedades de los primos
   if numeroAEvaluar%divisorActual==0:
    break
 divisorActual+=1
 if divisorActual>numeroAEvaluar**0.5:
  maxPrimo=numeroAEvaluar
 listaPrimos.append(numeroAEvaluar)
 print (maxPrimo,len(listaPrimos))
 
print ("20001th prime is",maxPrimo)